---
title: Two Worlds
slug: two-worlds
date: 2012-08-11
category: Self-Awareness & EQ
featured: true
archived: false
excerpt: My son and I sit two feet apart, him in a video game and me in the stock market, and neither of us is really looking up.
---

The guns went bang  
 Sending the bad guys  
 Down the castles and chutes  
 Bringing in additional power  
 For the game to advance to the next level  
 My nine year old jumped enthusiastically  
 Rejoicing at the victory without loss of ammunition  
 While I sat passively oblivious  
 My eyes engrossed in the World Wide Web  
 Watching the stock market go helter skelter

He looked around to share  
 His victory, his fear  
 Talking incessantly, he extolled the virtues  
 Lifeless I listened  
 His world did not seem important  
 As the global crisis exploded, I was  
 deep in thought at the macro impact  
 That game world was the big thing for him  
 While it seemed of least interest to me

I struggled to grasp the nuances of his school  
 While he patiently explained to a fool  
 How queer it seems  
 Two people under the same roof  
 Two different worlds that we live in  
 Two hearts that beat the same  
 But the sound that makes it dance is different
