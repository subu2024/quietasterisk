---
title: Made for Each Other
slug: made-for-each-other
date: 2000-02-24
category: Old Voice
featured: true
archived: false
excerpt: We were supposed to fit, and I'm still trying to understand why we never
  quite did.
---
She cried, he laughed  
 He fretted, she threw tantrums  
 Day every day, they grew far apart  
 They were just not made for each other

Like the bright sun on a rainy day  
 Together they seemed never right  
 Further they went, better they felt  
 No! They were not perfect for each other

Sometimes they held and cuddled  
 Like lovers lost in time and space  
 Only to break up loud and clear  
 Leaving friends and family equally befuddled

Her cries left him no patience  
 His anger gave her no choice  
 A daily melodrama, their life was sour  
 Making the process of living slow

All things that don’t fit  
 Every pair that failed to happen  
 Together they made that seem possible  
 They were just not made for each other
