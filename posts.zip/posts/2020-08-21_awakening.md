---
title: Awakening
date: 2020-08-21
category: Old Voice
featured: true
archived: false
excerpt: I let go of wanting things, and something quieter finally had room to show up.
slug: awakening
---

Today I stand awakened  
 Asking questions that I seldom asked  
 Who am I? Why am I alive? What is my purpose?

Feeling a deep sense of detachment  
 To everything surrounding me including you  
 Letting go of every desire  
 Not letting it define me anymore  
 Removing every layer like shriveled fabric  
 To become completely transparent

Accepting the new found inner peace  
 Life is what it is  
 Never better, never worse  
 Allowing the universe to conspire  
 to make something beautiful happen

Slowly losing all fear  
 For fear is nothing but fear of death  
 living fully in the present  
 Not worrying about the future  
 Nor regretting the past

Finding my way to the eternal state of happiness  
 Not by rearranging the circumstances of my life  
 But by realizing myself at the deepest level  
 and oneness with the universe
