---
title: The Invite
slug: the-invite
date: 2013-12-06
category: Old Voice
featured: false
archived: false
excerpt: The diagnosis came, and so did an anger I didn't know I was capable of.
---
The doctor pronounced the verdict  
 The cancer had taken over his world of breathe  
 The soft comfortable voice masked the dire predict  
 As he slowly unfolded the invitation to death

The initial shock gave way to anger and spite  
 Why me?  
 He was not ready, as he expected a happy respite  
 The invite did not hide, standing sore as acne

He clutched the chair hard and wanted to fight  
 It is for her and them that he aspired to be alive  
 Beside him she stood, tears rolling, holding tight  
 The beacon was visibly clear to read the invite

The pending affairs, the children,  
 The wealth, the many unsaid things momentarily burnt  
 All images, visible thoughts raced in a flash without any turn  
 To read the invitation that lay crumbled right in front

The irony of life, the desire to live  
 The purpose of hope, the unfulfilled desire  
 The story remained doomed even before beginning the last dive  
 The invitation was impossible to ignore lying in mire

But he smiled as he leaned forward  
 Defeat was not his dream to reach and go  
 He will fight till he could and march onward  
 The invitation can wait, he decided to not accept but forgo
