---
title: The Shrine of Disney
slug: the-shrine-of-disney
date: 2010-12-27
category: Old Voice
featured: true
archived: false
excerpt: The anticipation leading up to that trip turned out to be its own kind of magic.
---

My wait begins the moment I book the tickets  
 The expectations surge daily, running high in adrenaline  
 The anticipation overwhelms as I step on the magical land  
 Rushing to see the Gods in the holy shrine

The mood remains jubilant, my heart skips a beat  
 The guards whisk and search as I enter the secure seat  
 Behind them await the delightful sight of Mickey and Goofy  
 Inviting me by sight and sound into the inner sanctum treat

The devotees abound all around  
 From young to old, age has zero stand  
 Their prayers range from muttering to chanting to yeahs  
 Just everyone was feeling blessed to be in the Promised Land

The lines were large for the rides  
 The few chosen ones got the fast-pass, bypassing the common maneuver  
 Holding their hearts in anticipation, constant smile on face  
 They roller coaster the exotic rugged terrains with a religious fervor

They gulp the food whatever scant is available  
 There was no complaints just satisfaction  
 The sheer joy of dining in the special land  
 Lends the magic to keep everyone calm without any friction

The endless parade of colorful Gods  
 Culminates in a display of fireworks - Fantasmic  
 The sound of clap resonates the thank you to the deities  
 For allowing us to bask in the reflected glory cosmic

The night gives way to sheer exhaustion  
 As the crowd makes the way to exit Door  
 I turn one last time to drink the remaining nectar  
 Promising to visit again to re-witness the splendor
