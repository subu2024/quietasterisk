---
title: Living the Dead Life
slug: living-the-dead-life
date: 2010-05-23
category: Old Voice
featured: true
archived: false
excerpt: I keep chasing the next stage of life instead of actually living the one
  I'm in.
---
As an eight year old, he lived like a king  
 Immersed in the little world with a baby zing  
 Soon he was forced to imbibe the knowledge drink  
 to long for the day when he could live and sing

In his youth, he chased the dream job  
 Other time, he raced for the beautiful girl with a bob  
 Planning to live someday when he had his time to lob  
 Forgetting the present, he was riding the future cob

Now a dad, he constantly cared  
 Worrying about his children all day, he prayed  
 His life only revolved around them and not shared  
 Eclipsed by the shadow of his family, change he not dared

Slowly growing old, his body buckled and refused  
 Although the world and the green prompted to be seduced  
 He could not bring his body to cooperate or enthused  
 The dream still remained, immense and profused

Now lying pale on his deathbed  
 He realized a little too late instead  
 He had died long back, life that he never lived nor led  
 Today, only his body was getting ready for the heavenly bed
